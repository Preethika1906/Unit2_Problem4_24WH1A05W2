# DAA Macro Project – Greedy Job Sequencing

## Selected Topic
**Greedy Job Sequencing Flowchart: Decision path visualization for job selection based on deadlines and profits.**

This package follows the same deliverable style as the supplied reference project.

## Contents
- `Unit1_Greedy_Method/Greedy_Job_Sequencing.java` – Java implementation
- `Unit1_Greedy_Method/Algorithm_Pseudocode.txt` – algorithm/pseudocode
- `Unit1_Greedy_Method/Prompt.txt` – AI visualization prompt
- `Unit1_Greedy_Method/Visualization.png` – flowchart / decision path
- `Unit1_Greedy_Method/Sample_Output.txt` – sample output
- `Unit1_Greedy_Method/README.md` – project README
- `PPT/Greedy_Job_Sequencing.pptx` – presentation

## Topic Outcome
**Decision path visualization:** the flowchart shows how jobs are selected
according to profit and placed into available slots without violating their
deadlines.
