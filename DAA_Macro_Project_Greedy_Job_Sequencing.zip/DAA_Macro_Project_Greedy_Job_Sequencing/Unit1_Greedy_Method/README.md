# Greedy Job Sequencing with Deadlines and Profits

## Description
This project implements the Greedy Job Sequencing problem. Each job has a
deadline and a profit, and every job requires one unit of time. The objective
is to select and schedule jobs so that the total profit is maximized while
each selected job is completed before or on its deadline.

## Input
| Job | Deadline | Profit |
|---|---:|---:|
| J1 | 2 | 100 |
| J2 | 1 | 19 |
| J3 | 2 | 27 |
| J4 | 1 | 25 |
| J5 | 3 | 15 |

Maximum deadline: **3**

## Greedy Strategy
1. Sort all jobs in descending order of profit.
2. Consider the highest-profit job first.
3. Place it in the latest free time slot not exceeding its deadline.
4. If no slot is available, reject the job.
5. Continue until all jobs are processed.

For the given input, the selected jobs are:
**J3, J1, J5**

Maximum Profit: **142**

## Flowchart / Decision Path
`Visualization.png` shows the complete decision flow:
- Check whether a free slot exists.
- Schedule the job if the answer is YES.
- Reject it if the answer is NO.
- Continue until all jobs are processed.

## Running the Java Program
```bash
javac Greedy_Job_Sequencing.java
java Greedy_Job_Sequencing
```

## Complexity
- Time Complexity: **O(n log n + n × d)**, where d is the maximum deadline.
- Space Complexity: **O(d)** for the scheduling slots.

## Learning Outcome
- Understood the Greedy method.
- Learned how deadlines affect job selection.
- Learned how sorting by profit leads to a high-profit schedule.
- Understood decision paths in a greedy scheduling algorithm.
- Practiced algorithm documentation and visualization.
