import java.util.*;

public class Greedy_Job_Sequencing {
    static class Job {
        String id;
        int deadline;
        int profit;

        Job(String id, int deadline, int profit) {
            this.id = id;
            this.deadline = deadline;
            this.profit = profit;
        }
    }

    public static void main(String[] args) {
        Job[] jobs = {
            new Job("J1", 2, 100),
            new Job("J2", 1, 19),
            new Job("J3", 2, 27),
            new Job("J4", 1, 25),
            new Job("J5", 3, 15)
        };

        System.out.println("Greedy Job Sequencing with Deadlines and Profits");
        System.out.println("===============================================");
        System.out.println("Jobs:");

        for (Job job : jobs) {
            System.out.println(job.id + " -> Deadline: " + job.deadline
                    + ", Profit: " + job.profit);
        }

        // Sort jobs in descending order of profit.
        Arrays.sort(jobs, (a, b) -> b.profit - a.profit);

        int maxDeadline = 0;
        for (Job job : jobs) {
            maxDeadline = Math.max(maxDeadline, job.deadline);
        }

        String[] slot = new String[maxDeadline + 1];
        int totalProfit = 0;

        System.out.println("\nJobs considered in descending profit order:");

        for (Job job : jobs) {
            boolean scheduled = false;

            // Try to place the job in the latest free slot
            // not exceeding its deadline.
            for (int t = Math.min(job.deadline, maxDeadline); t >= 1; t--) {
                if (slot[t] == null) {
                    slot[t] = job.id;
                    totalProfit += job.profit;
                    scheduled = true;
                    System.out.println(job.id + " -> Scheduled in Slot " + t);
                    break;
                }
            }

            if (!scheduled) {
                System.out.println(job.id + " -> Not scheduled (no free slot)");
            }
        }

        System.out.println("\nFinal Job Sequence:");
        for (int t = 1; t <= maxDeadline; t++) {
            System.out.println("Slot " + t + " -> " + slot[t]);
        }

        System.out.println("\nMaximum Profit: " + totalProfit);
    }
}
